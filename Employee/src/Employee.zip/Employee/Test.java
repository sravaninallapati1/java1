package Employee;
import java.io.*;
import java.util.*;

 class LoanException extends Exception {


public String toString()
{
	return "you are not eligible";
}
}

 class Test  implements Serializable{



 

 Scanner sc=new Scanner(System.in);
 int n=sc.nextInt();
 Employee[] empArray=new Employee[n];
public void insert() throws Exception
{
	 Employee empBean;
        for(int i=0;i<=1;i++)
{
        	empBean=new Employee();
System.out.println("enter employee id");
empBean.setId(sc.nextInt());
System.out.println("enter name");
empBean.setName(sc.next());
System.out.println("enter location");
empBean.setLocation(sc.next());
System.out.println("enter loan");
empBean.setLoan(sc.nextLong());
System.out.println("enter salary");
empBean.setSalary(sc.nextLong());
System.out.println("enter emi");
empBean.setEmi(sc.nextInt());
System.out.println("enter exp");
empBean.setExp(sc.nextInt());
 empArray[i]=empBean;
}

FileOutputStream fos= new FileOutputStream("d:/sravani.text");
ObjectOutputStream oos= new ObjectOutputStream(fos);
oos.writeObject(empArray);
System.out.println("after serialization");

}
public void delete() throws Exception
{
	FileInputStream fis= new FileInputStream("d:/sravani.text");
    ObjectInputStream ois= new ObjectInputStream(fis);
    Employee[] empArray=(Employee[])ois.readObject();
 
    System.out.println("after deserialization");

	 System.out.println("enter the id to delete");
	    int tempid;
       tempid=sc.nextInt();
       for(int i=0;i<=1;i++)
       {
    	   Employee emp=(Employee)empArray[i];
    	   if(empArray[i]==null)
    	   {
    		   System.out.println("id is not present");
    	   }
    	   else if(tempid==emp.getId())
    	   {
    	     
    	      emp.setId(0);
    	      emp.setName(null);
    	      emp.setLocation(null);
    	      emp.setLoan(0);
    	      emp.setEmi(0);
    	      emp.setExp(0);
    	      emp.setSalary(0);
    		  empArray[i]=emp;
    		  System.out.println("the id is deleted");
    	   }
    	   else
    		   if(emp.getId()==0)
    		   {
    			   System.out.println("there is another chance to fill the array size");
    		   }
       }
       
       
       
}
public void update()throws Exception
{
	 
     FileInputStream fis= new FileInputStream("d:/sravani.text");
     ObjectInputStream ois= new ObjectInputStream(fis);
     Employee[]empArray=(Employee[])ois.readObject();

	 System.out.println("enter the id to update");
     int j=sc.nextInt();
      System.out.println("enter name to update");
      
     for(int i=0;i<=1;i++)
      {
	
	   Employee emp=(Employee)empArray[i];
	   if(empArray[i]==null)
	   {
		   System.out.println("id is not present");
	   }
	   if(emp.getId()==j)
	   {
		  
		  emp.setName(sc.next());
		  emp.setLocation(sc.next());
		  
		  empArray[i]=emp;
		  System.out.println(i+1 +"details");
   	   System.out.println("id= "+ emp.getId());
   	   System.out.println("name ="+ emp.getName());
   	   System.out.println("location= "+ emp.getLocation());
   	   System.out.println("loan= "+ emp.getLoan());
   	   System.out.println("salary= "+ emp.getSalary());
   	   System.out.println("emi= "+ emp.getEmi());
   	   System.out.println("experience= "+ emp.getExp());
    }
	   }
	  
      
}    	   
     
     


public void loan()throws Exception
{
	FileInputStream fis= new FileInputStream("d:/sravani.text");
    ObjectInputStream ois= new ObjectInputStream(fis);
    Employee[]empArray=(Employee[])ois.readObject();
 
    System.out.println("after deserialization");
	for(int i=0;i<=1;i++)
    {
       Employee emp=(Employee)empArray[i];
       if(empArray[i]==null)
	   {
		   System.out.println("id is not present");
	   }
       else  if(emp.getExp()>=2&&emp.getExp()<3&&emp.getSalary()>=240000&&emp.getSalary()<300000)
       {
    	   System.out.println("you are eligible for half packge");
    	   long loan=emp.getSalary()/2;
    	   int emi=(int)((loan*14)/9*100);
    	   emp.setLoan(loan);
    	   emp.setEmi(emi);   
    	   empArray[i]=emp;
    	   System.out.println(i+1 +"details");
    	   System.out.println("id= "+ emp.getId());
    	   System.out.println("name ="+ emp.getName());
    	   System.out.println("location= "+ emp.getLocation());
    	   System.out.println("salary= "+ emp.getSalary());
    	   System.out.println("loan= "+ emp.getLoan());
    	   System.out.println("emi= "+ emp.getEmi());
    	   System.out.println("experience= "+ emp.getExp());
       }
       else if(emp.getExp()>=3&&emp.getSalary()>=300000)
       {
    	   System.out.println("you are eligible for 3/4th packge");
    	   long loan=emp.getSalary()*3/4;
    	   int emi=(int)((loan*14)/9*100);
    	   emp.setLoan(loan);
    	   emp.setEmi(emi);
    	   empArray[i]=emp;
    	   System.out.println(i+1 +"details");
    	   System.out.println("id= "+ emp.getId());
    	   System.out.println("name ="+ emp.getName());
    	   System.out.println("location= "+ emp.getLocation());
    	   System.out.println("salary= "+ emp.getSalary());
    	   System.out.println("loan= "+ emp.getLoan());
    	   System.out.println("emi= "+ emp.getEmi());
    	   System.out.println("experience= "+ emp.getExp());
       }
       else
       {
    	   try
    	   {
    		   throw new LoanException();
    	   }
    	 
    	   catch(Exception e)
    	   {
    	   System.out.println(e);
    	   }
       }
       
       }
       
       
}

public void view() throws Exception
{
	FileInputStream fis= new FileInputStream("d:/sravani.text");
    ObjectInputStream ois= new ObjectInputStream(fis);
    Employee[]empArray=(Employee[])ois.readObject();
 
    System.out.println("after deserialization");

	int ms;
     System.out.println("enter id to view");
    int k=sc.nextInt();
    for(int i=0;i<=1;i++)
    {
   	Employee emp=(Employee)empArray[i];
    if(empArray[i]==null)
	   {
		   System.out.println("id is not present");
	   }
    else	if(emp.getId()==k)
   	{
   	 ms=(int)(emp.getSalary()-emp.getEmi());
   	 emp.setMs(ms);
    }
    }
    for(int i=0;i<=1;i++)
      {
   	   Employee emp=(Employee)empArray[i];
    	   System.out.println(i+1 +"details");
    	   System.out.println("id= "+ emp.getId());
    	   System.out.println("name ="+ emp.getName());
    	   System.out.println("location= "+ emp.getLocation());
    	   System.out.println("salary= "+ emp.getSalary());
    	   System.out.println("loan= "+ emp.getLoan());
    	   System.out.println("emi= "+ emp.getEmi());
    	   System.out.println("experience= "+ emp.getExp());
    	   System.out.println("ms= "+ emp.getMs());
      }
    
    }


public static void main(String[] args) throws Exception
{
	System.out.println("enter the no of employes");
Scanner sc = new Scanner(System.in);
	Test t=new Test();
	
	while(true)
	{
	System.out.println("1.insert");
	System.out.println("2.delete");
	System.out.println("3.update");
	System.out.println("4.loan");
	System.out.println("5.view");
	System.out.println("6.exit");
	System.out.println("enter your choice");
	int s=sc.nextInt();
	
	
	
	switch(s)
	{
	case 1:   t.insert();         
		               
	        break;
	       
	case 2: 
	         t.delete();
		   
	      
	       break;
	case 3: 
		   t.update();
          break;
           
	case 4:    t.loan();
		       break;
	          
	case 5:  t.view();
	         break;
	case 6: System.exit(0);
	        break;
	default: System.out.println("no case");
             break;
	
	
}

}
}
}

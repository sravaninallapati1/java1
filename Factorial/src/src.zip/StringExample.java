
public class StringExample
{
	  public static void main(String[]args)
	  {
		  String s1=new String("dhatri");
		  String s2= "dhatri" ;
		  String s3= new String("dhatri");
		  String s4= "dhatri" ;
		  if(s1.equals(s4))
		  {
			  System.out.println(" content same") ;
			  
		  }
		  else
			  System.out.println("different content") ;
		  if(s1==s2)
		  {
			  System.out.println("same ref") ;
			  
		  }
		  else
			  System.out.println("different ref") ;
	  
	    s1=new String("info") ;
	    s1= " india" ;
	    
	  }
}
	  
	  


